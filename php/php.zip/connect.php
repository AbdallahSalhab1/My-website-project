<?php
$host="localhost";
$dbName="abdalla2_webairport";
$user="root";
$password="";

$pdo=new PDO("mysql:host=$host;dbname=$dbName",$user,$password);

?>